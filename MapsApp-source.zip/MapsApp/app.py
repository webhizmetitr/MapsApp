"""Turkish desktop interface for finding Places records without websites."""
import queue
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

from locations import ALL_DISTRICTS, DISTRICTS, selected_districts
from places import PlacesError, export_csv, search_province


class MapsApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MapsApp • İl / İlçe Taraması • v2.0")
        self.geometry("1150x740")
        self.minsize(850, 600)
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.businesses = []
        self.running = False
        self.key = tk.StringVar()
        self.city = tk.StringVar()
        self.district = tk.StringVar()
        self.sector = tk.StringVar()
        self.estimate = tk.StringVar(value="İl ve ilçe seçin. Google'ın sunduğu sayfalar otomatik taranır.")
        self.status = tk.StringVar(value="Arama için il ve ilçe seçin; sektör girin.")
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.after(100, self._poll)

    def _build(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        form = ttk.Frame(self, padding=20)
        form.grid(row=0, column=0, sticky="ew")
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text="Web sitesi bilgisi olmayan işletmeleri bulun", font=("Segoe UI", 17, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 15))
        ttk.Label(form, text="Places API anahtarı").grid(row=1, column=0, sticky="w", padx=(0, 12))
        self.key_entry = ttk.Entry(form, textvariable=self.key, show="•")
        self.key_entry.grid(row=1, column=1, columnspan=3, sticky="ew", pady=4)
        self.inputs = [self.key_entry]
        ttk.Label(form, text="İl (Türkiye)").grid(row=2, column=0, sticky="w")
        self.city_select = ttk.Combobox(form, textvariable=self.city, values=tuple(DISTRICTS), state="readonly", height=20)
        self.city_select.grid(row=2, column=1, columnspan=3, sticky="ew", pady=4)
        self.city_select.bind("<<ComboboxSelected>>", self._city_changed)
        ttk.Label(form, text="İlçe").grid(row=3, column=0, sticky="w")
        self.district_select = ttk.Combobox(form, textvariable=self.district, state="readonly", height=20)
        self.district_select.grid(row=3, column=1, columnspan=3, sticky="ew", pady=4)
        self.district_select.bind("<<ComboboxSelected>>", self._update_estimate)
        ttk.Label(form, text="Sektör").grid(row=4, column=0, sticky="w")
        self.sector_entry = ttk.Entry(form, textvariable=self.sector)
        self.sector_entry.grid(row=4, column=1, columnspan=3, sticky="ew", pady=4)
        self.inputs.append(self.sector_entry)
        ttk.Label(form, textvariable=self.estimate, wraplength=1000).grid(row=5, column=0, columnspan=4, sticky="w", pady=4)
        ttk.Label(form, text="Her ilçede Google'ın sunduğu tüm sayfalar taranır (en fazla 60 kayıt/ilçe ve sektör). Tam liste garantisi yoktur.", wraplength=1000).grid(
            row=6, column=0, columnspan=4, sticky="w", pady=4)
        ttk.Label(form, text="Google Places API (New) ve faturalandırma açık olmalıdır. Anahtar diske kaydedilmez.").grid(
            row=7, column=0, columnspan=4, sticky="w")
        actions = ttk.Frame(form)
        actions.grid(row=8, column=0, columnspan=4, sticky="w", pady=(12, 0))
        self.search_button = ttk.Button(actions, text="Seçili bölgeyi tara", command=self._search)
        self.search_button.pack(side="left")
        self.stop_button = ttk.Button(actions, text="Durdur", command=self._stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.export_button = ttk.Button(actions, text="CSV / Excel'e aktar", command=self._export, state="disabled")
        self.export_button.pack(side="left")
        ttk.Button(actions, text="Haritada aç", command=self._open_map).pack(side="left", padx=8)
        self.spinner = ttk.Progressbar(form, mode="indeterminate")
        self.spinner.grid(row=9, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        results = ttk.Frame(self, padding=(20, 0))
        results.grid(row=1, column=0, sticky="nsew")
        results.rowconfigure(0, weight=1)
        results.columnconfigure(0, weight=1)
        self.table = ttk.Treeview(results, columns=("name", "address", "phone"), show="headings", selectmode="browse")
        for column, title, width in (("name", "İşletme", 270), ("address", "Adres", 550), ("phone", "Telefon", 150)):
            self.table.heading(column, text=title)
            self.table.column(column, width=width, minwidth=100)
        self.table.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(results, orient="vertical", command=self.table.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.bind("<Double-1>", lambda event: self._open_map())
        footer = ttk.Frame(self, padding=20)
        footer.grid(row=2, column=0, sticky="ew")
        ttk.Label(footer, textvariable=self.status, wraplength=1000).pack(anchor="w")
        ttk.Label(footer, text="Filtre Google kaydına dayanır; web sitesinin kesinlikle olmadığını veya tüm işletmelerin bulunduğunu garanti etmez.",
                  wraplength=1000).pack(anchor="w", pady=(8, 0))
        ttk.Label(footer, text="Google Maps verileri • https://maps.google.com • Kullanım ve saklama için Google Maps Platform koşulları geçerlidir.",
                  wraplength=1000).pack(anchor="w", pady=(4, 0))

    def _set_running(self, running):
        self.running = running
        for entry in self.inputs:
            entry.configure(state="disabled" if running else "normal")
        self.city_select.configure(state="disabled" if running else "readonly")
        self.district_select.configure(state="disabled" if running else "readonly")
        self.search_button.configure(state="disabled" if running else "normal")
        self.stop_button.configure(state="normal" if running else "disabled")
        self.export_button.configure(state="normal" if self.businesses and not running else "disabled")
        if running:
            self.spinner.start(12)
        else:
            self.spinner.stop()

    def _city_changed(self, event=None):
        districts = DISTRICTS.get(self.city.get(), ())
        self.district_select.configure(values=(ALL_DISTRICTS, *districts) if districts else ())
        self.district.set(ALL_DISTRICTS if districts else "")
        self._update_estimate()

    def _update_estimate(self, event=None):
        try:
            count = len(selected_districts(self.city.get(), self.district.get()))
        except ValueError:
            self.estimate.set("İl ve ilçe seçin.")
            return
        self.estimate.set(f"Bu seçim: {count} ilçe · En fazla {count * 3} API isteği. İstekler ücretli olabilir; kota sınırınızı kontrol edin.")

    def _search(self):
        if self.running:
            return
        values = (self.key.get().strip(), self.city.get(), self.district.get(), self.sector.get().strip())
        if not all(values):
            messagebox.showwarning("Eksik bilgi", "API anahtarını ve sektörü girin; listeden il ve ilçe seçin.")
            return
        try:
            selected_districts(values[1], values[2])
        except ValueError as exc:
            messagebox.showwarning("Geçersiz bölge", str(exc))
            return
        self.businesses = []
        self.table.delete(*self.table.get_children())
        self.cancel.clear()
        self._set_running(True)
        self.status.set("Google üzerinde aranıyor…")

        def worker():
            try:
                result = search_province(*values, cancelled=self.cancel.is_set,
                    on_page=lambda rows, status: self.events.put(("page", (rows, status))))
                self.events.put(("done", result))
            except PlacesError as exc:
                self.events.put(("error", str(exc)))
            except Exception:
                self.events.put(("error", "Beklenmeyen bir hata oluştu. Aramayı yeniden deneyin."))
        threading.Thread(target=worker, daemon=True).start()

    def _stop(self):
        self.cancel.set()
        self.stop_button.configure(state="disabled")
        self.status.set("Durduruluyor; devam eden isteğin tamamlanması bekleniyor (en fazla 30 saniye)…")

    def _poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "page":
                    rows, status = value
                    for business in rows:
                        index = len(self.businesses)
                        self.businesses.append(business)
                        self.table.insert("", "end", iid=str(index), values=(business.name, business.address, business.phone))
                    if not self.cancel.is_set():
                        self.status.set(f"İlçe {status.query_number}/{status.total_queries}: {status.district} · {status.requests} API isteği · "
                                        f"{status.scanned} kayıt incelendi · {status.found} benzersiz web sitesi bilgisi olmayan işletme.")
                elif kind == "error":
                    self._set_running(False)
                    self.status.set("Tarama tamamlanamadı. Alınmış sonuçlar listede ve dışa aktarılabilir.")
                    messagebox.showerror("Arama hatası", value)
                else:
                    self.businesses = value.businesses
                    self._set_running(False)
                    suffix = " Durduruldu; alınan sonuçlar korundu." if value.stopped else " Tarama tamamlandı."
                    if value.capped:
                        suffix += " Google'ın sorgu başına sonuç sınırına ulaşıldı."
                    if value.error:
                        suffix = " Hata nedeniyle tarama eksik; alınan sonuçlar korundu."
                    self.status.set(f"{value.completed_queries}/{value.total_queries} ilçe tamamlandı · {value.requests} API isteği · "
                                    f"{value.scanned} kayıt incelendi · {len(value.businesses)} benzersiz sonuç." + suffix)
                    if value.error:
                        messagebox.showerror("Tarama eksik", value.error + "\n\nAlınan sonuçları CSV olarak kaydedebilirsiniz.")
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _export(self):
        path = filedialog.asksaveasfilename(title="CSV kaydet", defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if path:
            try:
                export_csv(path, self.businesses)
                self.status.set(f"{len(self.businesses)} işletme CSV dosyasına aktarıldı.")
            except OSError:
                messagebox.showerror("Dosya hatası", "Dosya yazılamadı. İzinleri kontrol edin; dosya Excel'de açıksa kapatın.")

    def _open_map(self):
        selection = self.table.selection()
        if not selection:
            return
        url = self.businesses[int(selection[0])].maps_url
        parsed = urlparse(url)
        if parsed.scheme == "https" and parsed.hostname in {"maps.google.com", "www.google.com", "google.com", "maps.app.goo.gl"}:
            webbrowser.open(url)
        else:
            messagebox.showinfo("Harita", "Bu kayıt için geçerli bir Google Haritalar bağlantısı bulunamadı.")

    def _close(self):
        self.cancel.set()
        self.key.set("")
        self.destroy()


if __name__ == "__main__":
    MapsApp().mainloop()
