$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if ($env:OS -ne 'Windows_NT') { throw 'EXE derlemesi Windows üzerinde çalıştırılmalıdır.' }
py -3 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python 3 kurulumu gerekli.' }
& .\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
if ($LASTEXITCODE -ne 0) { throw 'Derleme bağımlılıkları kurulamadı.' }
& .\.venv\Scripts\python.exe -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw 'Testler başarısız.' }
& .\.venv\Scripts\python.exe tests/ui_smoke.py
if ($LASTEXITCODE -ne 0) { throw 'Arayüz kontrolü başarısız.' }
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name MapsApp app.py
if ($LASTEXITCODE -ne 0) { throw 'EXE oluşturulamadı.' }
Write-Host 'Hazır: dist\MapsApp.exe'
