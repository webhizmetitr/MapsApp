import csv
import io
import tempfile
import unittest
from pathlib import Path
from urllib.error import HTTPError, URLError
from unittest.mock import patch

from places import Business, PlacesError, export_csv, request_page, search_businesses


class SearchTests(unittest.TestCase):
    def test_pagination_filter_and_deduplication(self):
        calls = []
        pages = [
            {"places": [
                {"id": "a", "displayName": {"text": "Ankara Diş"}, "formattedAddress": "Çankaya",
                 "nationalPhoneNumber": "0312 123 45 67", "googleMapsUri": "https://maps.google.com/?cid=1"},
                {"id": "b", "websiteUri": "https://example.com"},
                {"id": "c", "websiteUri": "https://instagram.com/example"},
            ], "nextPageToken": "page-two"},
            {"places": [{"id": "a"}, {"id": "d", "websiteUri": ""}, {"displayName": {"text": "Missing ID"}}]},
        ]

        def fetch(key, payload):
            calls.append((key, payload))
            return pages[len(calls) - 1]

        result = search_businesses(" key ", " Ankara ", " diş kliniği ", max_pages=3, fetch=fetch)
        self.assertEqual(result.scanned, 4)
        self.assertEqual([b.place_id for b in result.businesses], ["a", "d"])
        self.assertEqual(result.businesses[0].name, "Ankara Diş")
        self.assertEqual(result.businesses[0].phone, "0312 123 45 67")
        self.assertEqual(calls[0][0], "key")
        self.assertEqual(calls[0][1]["textQuery"], "diş kliniği, Ankara, Türkiye")
        self.assertNotIn("pageToken", calls[0][1])
        self.assertEqual(calls[1][1]["pageToken"], "page-two")
        self.assertFalse(result.capped)

    def test_page_cap(self):
        calls = []
        def fetch(*args):
            calls.append(args)
            return {"places": [{"id": "a"}], "nextPageToken": "next"}
        result = search_businesses("key", "İzmir", "berber", fetch=fetch)
        self.assertEqual(len(calls), 1)
        self.assertTrue(result.capped)

    def test_cancel_retains_completed_page(self):
        stopped = False
        def progress(scanned, found):
            nonlocal stopped
            stopped = True
        result = search_businesses("key", "Bursa", "kafe", max_pages=3,
            cancelled=lambda: stopped, progress=progress,
            fetch=lambda *args: {"places": [{"id": "a"}], "nextPageToken": "next"})
        self.assertTrue(result.stopped)
        self.assertEqual(len(result.businesses), 1)

    def test_cancel_before_request(self):
        def fetch(*args):
            self.fail("Cancelled search must not make a paid request")
        result = search_businesses("key", "Bursa", "kafe", cancelled=lambda: True, fetch=fetch)
        self.assertTrue(result.stopped)
        self.assertEqual(result.scanned, 0)

    def test_empty_response(self):
        result = search_businesses("key", "Bursa", "kafe", fetch=lambda *args: {})
        self.assertEqual(result.businesses, [])
        self.assertEqual(result.scanned, 0)

    def test_invalid_inputs_never_call_api(self):
        for args, kwargs in [(("", "Ankara", "kafe"), {}),
                              (("key", " ", "kafe"), {}),
                              (("key", "Ankara", "kafe"), {"max_pages": 4})]:
            with self.subTest(args=args, kwargs=kwargs), self.assertRaises(PlacesError):
                search_businesses(*args, **kwargs, fetch=lambda *args: self.fail("Invalid input sent"))


class TransportTests(unittest.TestCase):
    @patch("places.urlopen")
    def test_request_fields_and_unicode(self, opener):
        opener.return_value.__enter__.return_value = io.BytesIO(b'{"places": []}')
        self.assertEqual(request_page("test-key", {"textQuery": "İstanbul"}), {"places": []})
        request = opener.call_args.args[0]
        self.assertEqual(request.full_url, "https://places.googleapis.com/v1/places:searchText")
        self.assertIn("places.websiteUri", request.get_header("X-goog-fieldmask"))
        self.assertEqual(request.get_header("X-goog-api-key"), "test-key")
        self.assertEqual(request.method, "POST")

    @patch("places.urlopen")
    def test_http_error_is_actionable_and_redacted(self, opener):
        opener.side_effect = HTTPError("https://example.com/secret", 403, "secret-key", {}, io.BytesIO(b"secret"))
        with self.assertRaises(PlacesError) as error:
            request_page("secret-key", {})
        self.assertIn("faturalandırma", str(error.exception))
        self.assertNotIn("secret", str(error.exception))
        self.assertEqual(opener.call_count, 1)

    @patch("places.urlopen", side_effect=URLError("sensitive-proxy-url"))
    def test_connection_error(self, opener):
        with self.assertRaises(PlacesError) as error:
            request_page("key", {})
        self.assertNotIn("sensitive", str(error.exception))

    @patch("places.urlopen")
    def test_invalid_json(self, opener):
        opener.return_value.__enter__.return_value = io.BytesIO(b"invalid")
        with self.assertRaises(PlacesError):
            request_page("key", {})


class CsvTests(unittest.TestCase):
    def test_turkish_csv_roundtrip_and_formula_protection(self):
        businesses = [Business("id", "İşletme; Çığ", 'Adres "A"\nİstanbul', "+90 555 123 45 67", "https://maps.google.com/"),
                      Business("id2", "  =HYPERLINK(1)", "@danger", "-123", "https://maps.google.com/")]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "results.csv"
            export_csv(str(path), businesses)
            self.assertTrue(path.read_bytes().startswith(b"\xef\xbb\xbf"))
            with path.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.reader(file, delimiter=";"))
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[1][0], "İşletme; Çığ")
        self.assertEqual(rows[1][1], 'Adres "A"\nİstanbul')
        self.assertEqual(rows[1][2], "'+90 555 123 45 67")
        self.assertTrue(rows[2][0].startswith("'"))
        self.assertTrue(rows[2][1].startswith("'"))


if __name__ == "__main__":
    unittest.main()
