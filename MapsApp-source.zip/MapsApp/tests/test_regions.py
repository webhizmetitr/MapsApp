import unittest

from locations import ALL_DISTRICTS, DISTRICTS, selected_districts
from places import PlacesError, search_province


class LocationTests(unittest.TestCase):
    def test_offline_coverage_and_province_membership(self):
        self.assertEqual(len(DISTRICTS), 81)
        self.assertEqual(sum(map(len, DISTRICTS.values())), 973)
        self.assertEqual(len(DISTRICTS['İstanbul']), 39)
        self.assertIn('Çankaya', DISTRICTS['Ankara'])
        self.assertIn('Kahramankazan', DISTRICTS['Ankara'])
        for province, districts in DISTRICTS.items():
            with self.subTest(province=province):
                self.assertTrue(districts)
                self.assertEqual(len(districts), len(set(districts)))
        self.assertEqual(selected_districts('Ankara', 'Çankaya'), ('Çankaya',))
        with self.assertRaises(ValueError):
            selected_districts('Ankara', 'Kadıköy')


class RegionalSearchTests(unittest.TestCase):
    def test_all_districts_deduplicate_and_complete(self):
        queries = []
        streamed = []

        def fetch(key, payload):
            queries.append(payload['textQuery'])
            return {'places': [{'id': 'same-business'},
                               {'id': str(len(queries)), 'websiteUri': 'https://example.com'}]}

        result = search_province('key', 'Ankara', ALL_DISTRICTS, 'kafe', fetch=fetch,
                                 on_page=lambda rows, progress: streamed.extend(rows))
        self.assertEqual(len(queries), 25)
        self.assertEqual(set(queries), {f'kafe, {district}, Ankara, Türkiye' for district in DISTRICTS['Ankara']})
        self.assertEqual(result.completed_queries, 25)
        self.assertEqual(result.requests, 25)
        self.assertEqual(result.scanned, 50)
        self.assertEqual([b.place_id for b in result.businesses], ['same-business'])
        self.assertEqual(streamed, result.businesses)
        self.assertFalse(result.error)

    def test_every_available_page_in_selected_district(self):
        calls = []
        def fetch(key, payload):
            calls.append(payload)
            number = len(calls)
            response = {'places': [{'id': f'page-{number}'}]}
            if number < 3:
                response['nextPageToken'] = f'token-{number}'
            return response
        result = search_province('key', 'Ankara', 'Çankaya', 'kafe', fetch=fetch)
        self.assertEqual(len(result.businesses), 3)
        self.assertEqual(result.requests, 3)
        self.assertEqual(result.completed_queries, 1)
        self.assertEqual(calls[1]['pageToken'], 'token-1')
        self.assertEqual(calls[2]['pageToken'], 'token-2')
        self.assertFalse(result.capped)

    def test_google_query_limit_remains_explicit(self):
        result = search_province('key', 'Ankara', 'Çankaya', 'kafe',
            fetch=lambda *args: {'places': [], 'nextPageToken': 'more'})
        self.assertEqual(result.requests, 3)
        self.assertTrue(result.capped)

    def test_api_error_preserves_completed_pages(self):
        calls = []
        streamed = []
        def fetch(*args):
            calls.append(args)
            if len(calls) == 2:
                raise PlacesError('Kota aşıldı')
            return {'places': [{'id': 'saved'}], 'nextPageToken': 'next'}
        result = search_province('key', 'Ankara', 'Çankaya', 'kafe', fetch=fetch,
            on_page=lambda rows, status: streamed.extend(rows))
        self.assertIn('Kota aşıldı', result.error)
        self.assertEqual(result.completed_queries, 0)
        self.assertEqual(result.scanned, 1)
        self.assertEqual(result.requests, 2)
        self.assertEqual([b.place_id for b in streamed], ['saved'])
        self.assertEqual(result.businesses, streamed)

    def test_cancellation_stops_more_paid_requests_and_keeps_rows(self):
        stopped = False
        def on_page(rows, status):
            nonlocal stopped
            stopped = True
        result = search_province('key', 'Ankara', ALL_DISTRICTS, 'kafe',
            cancelled=lambda: stopped, on_page=on_page,
            fetch=lambda *args: {'places': [{'id': 'saved'}], 'nextPageToken': 'next'})
        self.assertTrue(result.stopped)
        self.assertEqual(result.requests, 1)
        self.assertEqual(len(result.businesses), 1)

    def test_invalid_selection_never_calls_api(self):
        for province, district, sector in [('invalid', ALL_DISTRICTS, 'kafe'),
                                           ('Ankara', 'Kadıköy', 'kafe'),
                                           ('Ankara', 'Çankaya', '')]:
            with self.subTest(province=province, district=district), self.assertRaises(PlacesError):
                search_province('key', province, district, sector,
                                fetch=lambda *args: self.fail('Invalid selection sent'))


if __name__ == '__main__':
    unittest.main()
