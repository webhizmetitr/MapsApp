"""Run on a desktop (Windows or Xvfb). All Places requests use sample responses."""
import sys
import tempfile
import threading
import time
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
from locations import ALL_DISTRICTS
from places import PlacesError, search_province


def settle(root):
    deadline = time.monotonic() + 10
    while root.running and time.monotonic() < deadline:
        root.update()
        time.sleep(0.02)
    assert not root.running, 'Background scan did not complete'


root = app.MapsApp()
try:
    root.update()
    assert len(root.city_select['values']) == 81
    root.city.set('İstanbul')
    root._city_changed()
    assert len(root.district_select['values']) == 40
    assert root.district.get() == ALL_DISTRICTS
    assert '117 API' in root.estimate.get()
    root.district.set('Kadıköy')
    root.city.set('Ankara')
    root._city_changed()
    assert root.district.get() == ALL_DISTRICTS
    assert 'Kadıköy' not in root.district_select['values']
    assert '75 API' in root.estimate.get()
    root.district.set('Çankaya')
    root._update_estimate()
    assert '3 API' in root.estimate.get()
    root.key.set('test-key-not-a-real-credential')
    root.sector.set('diş kliniği')
    release = threading.Event()
    calls = []

    def fake_fetch(key, payload):
        calls.append(payload)
        assert payload['textQuery'] == 'diş kliniği, Çankaya, Ankara, Türkiye'
        assert release.wait(5), 'UI test did not release worker'
        if len(calls) == 1:
            return {'places': [{'id': 'test-id', 'displayName': {'text': 'Örnek Diş Kliniği'},
                'formattedAddress': 'Çankaya, Ankara', 'nationalPhoneNumber': '0312 123 45 67',
                'googleMapsUri': 'https://maps.google.com/?cid=1'}], 'nextPageToken': 'page-two'}
        return {'places': [{'id': 'has-site', 'websiteUri': 'https://example.com'}]}

    with patch('app.search_province', side_effect=lambda *args, **kwargs:
               search_province(*args, **kwargs, fetch=fake_fetch)):
        root._search()
        root.update()
        assert root.running
        assert root.city_select.instate(['disabled'])
        assert root.district_select.instate(['disabled'])
        release.set()
        settle(root)
    assert len(calls) == 2
    assert len(root.table.get_children()) == 1
    assert root.table.item('0', 'values')[0] == 'Örnek Diş Kliniği'
    assert root.export_button.instate(['!disabled'])
    assert str(root.city_select.cget('state')) == 'readonly'
    assert str(root.district_select.cget('state')) == 'readonly'
    assert '1/1 ilçe' in root.status.get()
    assert '2 API isteği' in root.status.get()
    with tempfile.TemporaryDirectory() as directory:
        output = Path(directory) / 'export.csv'
        with patch('app.filedialog.asksaveasfilename', return_value=str(output)):
            root._export()
        assert 'Örnek Diş Kliniği' in output.read_text(encoding='utf-8-sig')
    root.table.selection_set('0')
    with patch('app.webbrowser.open') as open_browser:
        root._open_map()
        open_browser.assert_called_once_with('https://maps.google.com/?cid=1')

    attempts = []
    def error_fetch(*args):
        attempts.append(args)
        if len(attempts) == 2:
            raise PlacesError('Örnek kota hatası')
        return {'places': [{'id': 'saved-before-error'}], 'nextPageToken': 'next'}
    with patch('app.search_province', side_effect=lambda *args, **kwargs:
               search_province(*args, **kwargs, fetch=error_fetch)), patch('app.messagebox.showerror') as show_error:
        root._search()
        settle(root)
        show_error.assert_called_once()
    assert len(root.table.get_children()) == 1
    assert root.export_button.instate(['!disabled'])
    assert 'eksik' in root.status.get()
    print('PASS: 81 provinces, dependent districts, reset, cost estimate, readonly states, '
          'paginated background scan, CSV, map link and partial results after API failure')
finally:
    root._close()
