# MapsApp 2.0

İl ve ilçeyi açılır menülerden seçerek Google Places API (New) üzerinden işletme arar.
`websiteUri` alanı boş olan kayıtları listeler. Türkçe masaüstü arayüzü,
telefon/adres bilgisi, Google Haritalar bağlantısı ve Excel uyumlu CSV aktarımı içerir.
81 il ve 973 ilçe çevrimdışı paketlenmiştir. İl değişince ilçe listesi yenilenir.
**Tüm ilçeler** seçeneği seçili ilin her ilçesinde belirtilen sektörü ayrı ayrı tarar;
tekrarlanan işletmeler Place ID üzerinden tekilleştirilir. Sonuçlar sayfa sayfa görünür;
durdurma veya API/kota hatasında alınan sonuçlar korunur ve CSV'ye aktarılabilir.

## Çalıştırma

Python 3.12 ve Tkinter gerekir (Windows Python kurulumunda tcl/tk seçili olmalıdır).
Çalışma sırasında üçüncü taraf Python paketi gerekmez:

```sh
python app.py
```

1. Google Cloud Console'da bir proje açın; faturalandırmayı ve **Places API (New)** hizmetini etkinleştirin.
2. Bir API anahtarı oluşturun ve API kısıtını Places API (New) olarak ayarlayın.
3. Anahtarı uygulamaya girin. Anahtar dosyaya veya kaynak koda kaydedilmez.
4. İl ve ilçe seçin; sektör girin (ör. Ankara / Çankaya / diş kliniği).
5. İlin tamamında taramak için ilçe menüsünden **Tüm ilçeler** seçin.
6. Ekrandaki azami API isteği sayısını kontrol edip **Seçili bölgeyi tara** düğmesine basın.
   Google'ın sunduğu sayfalar otomatik alınır. Sonuçları haritada açabilir veya CSV aktarabilirsiniz.

Kendi anahtarınızı kullanın; ortak bir anahtarı EXE içine gömmeyin. Masaüstü uygulamalarda
anahtar tamamen gizlenemez. Google Cloud'da uygun API/IP kısıtları, düşük kotalar ve bütçe
uyarıları ayarlayın; bütçe uyarısı harcamayı otomatik durdurmaz. Dağıtılacak ortak anahtarlı
bir ürün için sunucu tarafında kimlik doğrulamalı bir ara servis gerekir.

## Windows EXE

Windows x64 üzerinde Python 3.12 kurulu iken PowerShell ile:

```powershell
./build-windows.ps1
```

Çıktı: `dist/MapsApp.exe`. Kullanıcı bilgisayarında Python gerekmez.
EXE imzalı değildir; Windows SmartScreen uyarısı çıkabilir.
Linux PyInstaller doğrudan Windows EXE üretmez. Bu ortamda Windows Python 3.12.10 ve
PyInstaller 6.16.0, Wine üzerinden kullanılarak x64 EXE üretildi. Paketlenmiş EXE'nin
1150×740 arayüzü açıldı ve normal kapandığı kontrol edildi.
18 birim testi ile örnek verili il/ilçe, tarama, arayüz/CSV/harita bağlantısı kontrolleri de geçti.
Bu kontroller Wine altında yapıldı; gerçek Windows bilgisayarda ve gerçek API
anahtarıyla uçtan uca arama henüz doğrulanmadı.

Alternatif: Dosyaları GitHub'a gönderdikten sonra **Actions → Windows EXE → Run workflow**
çalıştırın ve `MapsApp-Windows-x64` çıktısını indirin. Workflow Windows'ta testleri ve
paketlemeyi çalıştırır; uygulamanın açılıp açık kaldığını kontrol eder. Bu kontrol gerçek API
aramasını doğrulamaz. Henüz çalıştırılmamış bir workflow başarılı kabul edilmemelidir.

## Sınırlar, maliyet ve veri kullanımı

- Her sayfa bir Text Search (New) isteğidir; Google sorgu başına en fazla 3 sayfa / 60 sonuç
  sunar. Kullanıcı artık manuel sayfa sınırı seçmez; sunulan sayfalar otomatik taranır.
  Tüm ilçeler seçeneği her ilçe için ayrı sorgu yapar. Örneğin İstanbul'un 39 ilçesi için
  en fazla 117 API isteği yapılır; sonuçlar tekilleştirilir. Google daha az sonuç döndürebilir.
  Bu bir şehirdeki tüm işletmelerin envanteri değildir; sektörler arasında otomatik tarama yapılmaz.
- Telefon ve web sitesi alanları ücretli üst seviye SKU kapsamına girebilir. Güncel
  [fiyatlandırmayı](https://developers.google.com/maps/billing-and-pricing/pricing)
  kontrol edin. Hatalarda otomatik tekrar yapılmaz.
- İl, ilçe ve sektör metin sorgusuna eklenir; idari sınır garantisi yoktur. Adresleri kontrol edin.
- İl/ilçe adları [bu açık idari ad listesinden](https://github.com/volkansenturk/turkiye-iller-ilceler)
  türetilmiştir. Kaynak, DASK'ın 2019 adres verisini belirtir; kaynak commit `locations.py` içinde kayıtlıdır.
  İdari ad değişiklikleri gelecekte veri güncellemesi gerektirebilir.
- Eksik `websiteUri`, işletmenin kesinlikle web sitesi olmadığı anlamına gelmez.
  Sosyal medya vb. herhangi bir web adresi olan kayıtlar da filtre dışında kalır.
- Durdur düğmesi devam eden isteği kesmez; mevcut istek bittikten sonra yeni sayfa istemez.
- API anahtarı ve arama sorgusu HTTPS üzerinden yalnızca Google Places uç noktasına gönderilir.
- CSV aktarımı teknik olarak mümkündür; Google verilerini kalıcı saklama, dışa aktarma,
  yeniden dağıtma ve ticari kullanımınız için [Google Maps Platform koşullarına](https://cloud.google.com/maps-platform/terms)
  ve [Places politikalarına](https://developers.google.com/maps/documentation/places/web-service/policies)
  uygunluğu ayrıca değerlendirin. Uygulama sınırsız saklama/yeniden kullanım izni sağlamaz.

## Testler

```sh
python -m unittest discover -s tests -v
```

Testler sahte API yanıtlarıyla filtreleme, sayfalama, durdurma, hata yönetimi ve CSV güvenliğini
doğrular. Masaüstü arayüz testi için ayrıca `python tests/ui_smoke.py` çalıştırılır;
Linux'ta bir ekran veya Xvfb gerekir. Gerçek API testi için kendi anahtarınızla tek ilçede arama yapın; Google kaydıyla
karşılaştırın. Geliştirme için mevcut checkout'u kullanın; yeni worktree gerekmez.
