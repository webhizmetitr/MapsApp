"""Google Places API (New) client. No API keys are persisted."""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from locations import selected_districts

ENDPOINT = "https://places.googleapis.com/v1/places:searchText"
FIELDS = ",".join(("places.id", "places.displayName", "places.formattedAddress",
                   "places.nationalPhoneNumber", "places.websiteUri",
                   "places.googleMapsUri", "nextPageToken"))


class PlacesError(Exception):
    pass


@dataclass(frozen=True)
class Business:
    place_id: str
    name: str
    address: str
    phone: str
    maps_url: str


@dataclass(frozen=True)
class SearchResult:
    businesses: list[Business]
    scanned: int
    stopped: bool
    capped: bool
    error: str = ""
    completed_queries: int = 0
    total_queries: int = 1
    requests: int = 0


@dataclass(frozen=True)
class ScanProgress:
    district: str
    query_number: int
    total_queries: int
    scanned: int
    found: int
    requests: int


def request_page(api_key: str, payload: dict) -> dict:
    request = Request(ENDPOINT, data=json.dumps(payload).encode("utf-8"), headers={
        "Content-Type": "application/json",
        "X-Goog-Api-Key": api_key,
        "X-Goog-FieldMask": FIELDS,
    }, method="POST")
    try:
        with urlopen(request, timeout=30) as response:
            data = json.load(response)
    except HTTPError as exc:
        # Do not echo remote error bodies: they may contain sensitive request data.
        messages = {
            400: "İstek reddedildi. Arama bilgilerini ve Places API (New) ayarlarını kontrol edin.",
            401: "API anahtarı kabul edilmedi.",
            403: "Erişim reddedildi. API anahtarını, kısıtlarını, Places API (New) ve faturalandırmayı kontrol edin.",
            429: "Google kotası veya istek sınırı aşıldı. Cloud Console üzerinden kontrol edin.",
        }
        raise PlacesError(messages.get(exc.code, f"Google hizmet hatası (HTTP {exc.code}). Daha sonra tekrar deneyin.")) from None
    except (URLError, TimeoutError, OSError):
        raise PlacesError("Google'a bağlanılamadı. İnternet/proxy bağlantısını kontrol edin.") from None
    except (ValueError, UnicodeError):
        raise PlacesError("Google'dan geçersiz bir yanıt alındı.") from None
    if not isinstance(data, dict):
        raise PlacesError("Google'dan beklenmeyen bir yanıt alındı.")
    return data


def search_businesses(api_key: str, city: str, sector: str, country: str = "Türkiye",
                      max_pages: int = 1, cancelled: Callable[[], bool] = lambda: False,
                      progress: Callable[[int, int], None] = lambda scanned, found: None,
                      fetch: Callable = request_page,
                      batch: Callable = lambda rows, scanned: None) -> SearchResult:
    api_key, city, sector, country = (value.strip() for value in (api_key, city, sector, country))
    if not all((api_key, city, sector, country)):
        raise PlacesError("API anahtarı, ülke, şehir ve sektör zorunludur.")
    if max_pages not in (1, 2, 3):
        raise PlacesError("Sayfa sınırı 1, 2 veya 3 olmalıdır.")
    payload = {"textQuery": f"{sector}, {city}, {country}", "languageCode": "tr", "pageSize": 20}
    seen: set[str] = set()
    found: list[Business] = []
    scanned = 0
    token = None
    for page in range(max_pages):
        if cancelled():
            return SearchResult(found, scanned, True, bool(token))
        if token:
            payload["pageToken"] = token
        data = fetch(api_key, dict(payload))
        page_found = []
        for place in data.get("places", []):
            place_id = place.get("id")
            if not place_id or place_id in seen:
                continue
            seen.add(place_id)
            scanned += 1
            if str(place.get("websiteUri") or "").strip():
                continue
            found.append(Business(place_id, place.get("displayName", {}).get("text", "İsimsiz işletme"),
                                  place.get("formattedAddress", ""), place.get("nationalPhoneNumber", ""),
                                  place.get("googleMapsUri", "")))
            page_found.append(found[-1])
        batch(page_found, scanned)
        progress(scanned, len(found))
        token = data.get("nextPageToken")
        if not token:
            break
    return SearchResult(found, scanned, cancelled(), bool(token))


def search_province(api_key: str, province: str, district: str, sector: str,
                    cancelled: Callable[[], bool] = lambda: False,
                    on_page: Callable = lambda rows, status: None,
                    fetch: Callable = request_page) -> SearchResult:
    """Scan every selected district and every available page (Google: up to 60/query).

    Publish completed pages immediately, preserve them on cancellation or API failure,
    and deduplicate across districts. Scanned counts may include cross-query repeats.
    """
    if not api_key.strip() or not sector.strip():
        raise PlacesError("API anahtarı ve sektör zorunludur.")
    try:
        districts = selected_districts(province, district)
    except ValueError as exc:
        raise PlacesError(str(exc)) from None
    found = []
    seen = set()
    scanned = requests = completed = 0
    capped = False

    def result(error=""):
        return SearchResult(found, scanned, cancelled(), capped, error,
                            completed, len(districts), requests)

    for number, area in enumerate(districts, start=1):
        if cancelled():
            return result()
        base_scanned = scanned

        def publish(rows, current_scanned):
            nonlocal scanned
            scanned = base_scanned + current_scanned
            unique = []
            for business in rows:
                if business.place_id not in seen:
                    seen.add(business.place_id)
                    unique.append(business)
            found.extend(unique)
            on_page(unique, ScanProgress(area, number, len(districts), scanned, len(found), requests))

        def counted_fetch(key, payload):
            nonlocal requests
            requests += 1
            return fetch(key, payload)

        try:
            area_result = search_businesses(api_key, f"{area}, {province}", sector,
                max_pages=3, cancelled=cancelled, fetch=counted_fetch, batch=publish)
        except PlacesError as exc:
            return result(f"{area}: {exc}")
        capped = capped or area_result.capped
        if area_result.stopped:
            return result()
        completed += 1
    return result()


def export_csv(path: str, businesses: list[Business]) -> None:
    # UTF-8 BOM and semicolons work well with Turkish Excel installations.
    def safe(value: str) -> str:
        # Prevent spreadsheet formula execution, including whitespace-prefixed values.
        return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value

    with open(path, "w", encoding="utf-8-sig", newline="") as output:
        writer = csv.writer(output, delimiter=";")
        writer.writerow(["İşletme", "Adres", "Telefon", "Google Haritalar", "Place ID"])
        for business in businesses:
            writer.writerow([safe(value) for value in (business.name, business.address, business.phone,
                                                       business.maps_url, business.place_id)])
